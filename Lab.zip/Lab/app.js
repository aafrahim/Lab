var express      = require('express');
var ejs		     = require('ejs');
var bodyParse  	 = require('body-parser');
var bodyParse  	 = require('body-parser');
var exSession  	 = require('express-session');
var cookieParser = require('cookie-parser');
var login        = require('./controllers/login');
var app          = express();

app.set('view engine', 'ejs');

app.use(bodyParse.urlencoded({extended:false}));
app.use(exSession({secret:"beware intruder!", saveUninitialized:true, resave:false}));
app.use(cookieParser());
app.use('/login', login);

app.listen(3000, function(){
	console.log('server started at 3000...');
});